var times = 0;

if(times == 0){
    $(function() {
        $("#myModal").modal('show');
    });
}
$(window).on('shown.bs.modal', function() {
//
    times = times + 1;
})


function newdone() {
    var myform = document.searchbar;

    if(myform.search.value==""){
        alert("please enter something to search for! ");
    }
    else if(myform.search.value=="energy"){
        window.open("https://www.google.com");
    }
    else if(myform.search.value=="balanced"){
        window.open("balanced.html");
    }
    else if(myform.search.value=="fitness"){
        window.open("fit.html");
    }
    else if(myform.search.value=="products"){
        window.open("products.html");
    }
    else if(myform.search.value=="restaurants"){
        window.open("restaurants.html");
    }
}